#include <ros/ros.h>

#include <iostream>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Twist.h>

using namespace std;

int main(int argc, char **argv)
{
	ros::init(argc,argv,"tortuga_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("tortuga_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Publisher pub = nh.advertise<geometry_msgs::Twist> ("/turtle1/cmd_vel", 1);

	geometry_msgs::Twist cmd_vel;
	int num;

	while (ros::ok())
	{
		cout << "Introduce una dirección:" << endl;
		cin >> num;

		switch(num) {
			case 2:
				cmd_vel.angular.z = -3.1416 / 2;
				break;
			case 4:
				cmd_vel.linear.x = -1;
				break;
			case 6:
				cmd_vel.linear.x = 1;
				break;
			case 8:
				cmd_vel.angular.z = 3.1416 / 2;
				break;
			default:
				break;
		}
		cmd_vel.linear.y = 0;
		cmd_vel.linear.z = 0;
		cmd_vel.angular.x = 0;
		cmd_vel.angular.y = 0;

		pub.publish(cmd_vel);
	}

    return 0;
}
