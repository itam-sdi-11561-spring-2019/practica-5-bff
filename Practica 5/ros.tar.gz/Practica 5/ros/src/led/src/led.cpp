#include <ros/ros.h>

#include <iostream>
#include <std_msgs/String.h>

using namespace std;

/**
*	source devel/setup.bash

**/

int main(int argc, char **argv)
{
	ros::init(argc,argv,"led_node");
	ros::NodeHandle nh;
	ROS_INFO_STREAM("led_node initialized");																																							
	ROS_INFO_STREAM(ros::this_node::getName());

	ros::Publisher pub = nh.advertise<std_msgs::String> ("/arduino_msg", 1);

	std_msgs::String msg;
	std::string m;

	while (ros::ok())
	{
		cout << "Introduce algo:" << endl;
		cin >> m;

		msg.data = m;
		pub.publish(msg);
	}

    return 0;
}
